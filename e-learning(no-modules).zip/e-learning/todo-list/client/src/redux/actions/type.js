export const ADDNEW_TODO = 'ADDNEW_TODO';
export const GETALL_TODO = 'GETALL_TODO';
export const TOGGLE_TODO = 'TOGGLE_TODO';
export const UPDATE_TODO = 'UPDATE_TODO';
export const DELETE_TODO = 'DELETE_TODO';

export const TOGGLE_TAB = 'TOGGLE_TAB';

export const ALL_TODOS = 'All Todos';
export const ACTIVE_TODOS = 'Active Todos';
export const DONE_TODOS = 'Done Todos';
export const TABS = [ALL_TODOS, ACTIVE_TODOS, DONE_TODOS];