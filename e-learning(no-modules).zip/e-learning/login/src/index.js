import express from 'express';
import path from 'path';
import bcrypt from 'bcrypt';
import { collection } from './config.js'; // Import the named export

const app = express();

// convert data into json format 
app.use(express.json());
app.use(express.urlencoded({extended:false}));

// Set ejs
app.set('view engine', 'ejs');

app.get('/', (req, res) => {
    res.render("login_signup");
});

app.get('/login_signup', (req, res) => {
    res.render("login_signup"); // Assuming "login_signup.ejs" is your login/signup page
});


// signup page functionality

app.post('/signup', async (req, res) => {
    const data={
        email: req.body.email,
        password: req.body.pass
    }



  // Validation script
        const userEmail = req.body.email;
        const usrPass = req.body.pass;
    // Regular expressions for email and password validation
        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        var passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

    // Check if email and password meet validation criteria
        if (emailRegex.test(userEmail) && passwordRegex.test(usrPass)) {
        // // Redirect to a new page if validation succeeds


       // check is user already exist 
       const existinguser = await collection.findOne({email:data.email});
       if(existinguser)
       {
           res.send("try another username");
       }else{

           // hash the password 
           const saltRounds = 10; // no of salt round for bcrypt
           const hashedPassword = await bcrypt.hash(data.password,saltRounds);
           data.password= hashedPassword; // replacing the original password with hash password

           // inserting data to database
           const userdata = await collection.insertMany(data);
           console.log(userdata); // showing in console
           res.send(`
           <script>
               alert("User SignUp Successfully!");
               window.location.href = "./login_signup"; // Redirect to login/signup page
           </script>
       `);

       }

        } else {
        res.send(`
            <script>
                alert("Invalid email or password. Please check your input.");
                window.location.href = "./login_signup"; // Redirect to login/signup page
            </script>
        `);
        }

});


// login user

app.post('/login', async (req,res)=>{
    try{
        const check = await collection.findOne({email:req.body.email});
        if(!check)
        {
            res.send(`
            <script>
                alert("User cannot found!");
                window.location.href = "./login_signup"; // Redirect to login/signup page
            </script>
        `);
        return;
        }
        // compare the hash password from the database with the plain text
        const isPasswordMatch = await bcrypt.compare(req.body.pass,check.password);
        if(isPasswordMatch)
        {
            res.redirect("http://localhost:3000/");
        }else{
            res.send(`
            <script>
                alert("Wrong password!");
                window.location.href = "./login_signup"; // Redirect to login/signup page
            </script>
        `);
        }
    }catch
    {
        res.send(`
        <script>
            alert("Wrong password!");
            window.location.href = "./login_signup"; // Redirect to login/signup page
        </script>
    `);
    }
})

const port = 5000;
app.listen(port, () => {
    console.log(`Server is running at ${port}`);
});

