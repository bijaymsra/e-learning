import './App.css';
import Home from './components/pages/Home';
import Contact  from './components/pages/Contact';
import About from './components/pages/About';
import {BrowserRouter as Router,Routes,Route} from 'react-router-dom';
import Service from './components/pages/Service';
import Premium from './components/pages/inc/Premium';
import Free from './components/pages/inc/Free';
import Note from './components/pages/note';

function App() {
  return (
    <Router>

    <div>
   <Routes>

      <Route exact path="/bijaymsra/Comprehensive-Learning" element={<Home/>} />
      <Route exact path="/" element={<Home/>} />

      <Route exact path="/premium" element={<Premium/>} />

      <Route exact path="/free" element={<Free/>} />

      <Route exact path="/service" element={<Service/>} />

      <Route exact path="/contact" element={<Contact/>} />

      <Route exact path="/about" element={<About/>} />

      <Route exact path="/note" element={<Note/>} />

      </Routes>
    </div>
    
    </Router>
  );
}

export default App;
