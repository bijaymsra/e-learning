import React  from "react";

function Vmc()
{
    return(

        <section className="section bg-c-light border-top">
        <div className="container">
            <div className="row">
                <div className="col-md-12 mb-5 text-center">
                    <h3 className='main-heading'>Vision , Mission and Values</h3>
                    <div className="underline mx-auto"></div>
                </div>
                <div className="col-md-4 text-center"> 
                    <h6>Vision</h6>
                    <p>CLR's vision is "a world where everyone has the opportunity to learn, grow, and achieve their full potential through quality education resources".</p>
                    <p>This statement emphasizes CLR's commitment to creating a world where individuals from all walks of life can access the educational resources they need to succeed.</p>
                        <p>It highlights the belief that quality education is a key driver of personal growth and achievement, regardless of background or financial constraints.</p>

                </div>

                <div className="col-md-4 text-center"> 
                    <h6>Our Mission</h6>
                    <p>CLR's mission is "to make education accessible and empowering by providing a comprehensive learning repository for individuals of all backgrounds and goals." This mission statement defines CLR's core purpose. Here's a breakdown of its key elements:</p>
                    <p>Accessibility: Ensuring that high-quality learning materials are available to everyone, regardless of financial limitations.</p>
                    <p>Empowerment: Furnishing individuals with the resources they need to take control of their learning journey and achieve their goals.</p>

                </div>

                <div className="col-md-4 text-center"> 
                    <h6>Our Core Values</h6>
                        <p>Building on its mission and vision, CLR likely adheres to certain core values that guide its operations. Here are some potential values CLR might embrace:
                        <p>Inclusivity: Providing a platform that welcomes and supports learners of all backgrounds.</p>
                        <p>Quality: Offering well-curated and effective learning resources.</p>
                        <p>Affordability: Making knowledge accessible through a free tier and affordable premium options.</p>
                        <p>Innovation: Continuously seeking to expand and improve its learning resource library.</p>
                    
                    
                    </p>

                </div>
            </div>
        </div>
    </section>

    );
}

export default Vmc;