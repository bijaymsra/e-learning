import React from "react";
import { Link } from 'react-router-dom';
import Services1 from './services/java.jpeg';
import Services2 from './services/python.jpeg';
import Services3 from './services/c.jpeg';
import Services4 from './services/database.jpeg';
import Services5 from './services/linux.jpeg';
import Services6 from './services/aws.jpeg';

function Free()
{

    return(

        <section className="section border-top">
        <div className="container">
            <div className="row">
                    <div className="col-md-12 mb-5 text-center">
                        <h3 className='main-heading'>Get Some Free Resources</h3>
                        <div className="underline mx-auto"></div>
                    </div>


                  <div className="col-md-4"> 
                  <div className="card shadow event-card event-card-hover"> 
                    <img src={Services6} className="w-100 border-bottom event-image" alt="Services" style={{height:'10rem'}}/> 
                    <div className="card-body event-info"> 
                    <center> <h3>AWS</h3>
                      <div className="underline"></div><br/>
                      <p>These are the best free Resources available, which best suits for you to study this program.</p>
                            <Link to="https://www.geeksforgeeks.org/aws-tutorial/" className="btn btn-link">Resource01</Link>
                            <Link to="https://www.javatpoint.com/aws-tutorial" className="btn btn-link">Resource02</Link>
                            <Link to="https://www.w3schools.com/aws/" className="btn btn-link">Resource03</Link></center>
                    </div>
                  </div>
                  </div>


                    <div className="col-md-4"> 
                    <div className="card shadow event-card event-card-hover"> 
                    <img src={Services2} className="w-100 border-bottom event-image" alt="Services" style={{height:'10rem'}}/> 
                    <div className="card-body event-info"> 
                    <center> <h3>Python</h3>
                      <div className="underline"></div><br/>
                      <p>These are the best free Resources available, which best suits for you to study this program.</p>
                            <Link to="https://www.geeksforgeeks.org/python-programming-language/" className="btn btn-link">Resource01</Link>
                            <Link to="https://www.javatpoint.com/python-tutorial" className="btn btn-link">Resource02</Link>
                            <Link to="https://www.w3schools.com/python/" className="btn btn-link">Resource03</Link></center>
                    </div>
                    </div>
                    </div>


                    <div className="col-md-4"> 
                    <div className="card shadow event-card event-card-hover"> 
                    <img src={Services5} className="w-100 border-bottom event-image" alt="Services" style={{height:'10rem'}}/> 
                    <div className="card-body event-info"> 
                    <center> <h3>Linux</h3>
                      <div className="underline"></div><br/>
                      <p>These are the best free Resources available, which best suits for you to study this program.</p>
                            <Link to="https://www.simplilearn.com/free-linux-foundation-course-skillup" className="btn btn-link">Resource01</Link>
                            <Link to="https://www.netacad.com/courses/os-it/ndg-linux-unhatched" className="btn btn-link">Resource02</Link>
                            <Link to="https://www.mygreatlearning.com/academy/learn-for-free/courses/linux-tutorial" className="btn btn-link">Resource03</Link></center>
                    </div>
                    </div>
                    </div>


                    <div className="col-md-4"> 
                    <div className="card shadow event-card event-card-hover"> 
                    <img src={Services3} className="w-100 border-bottom event-image" alt="Services" style={{height:'10rem'}} /> 
                    <div className="card-body event-info"> 
                    <center> <h3>C/C++</h3>
                      <div className="underline"></div><br/>
                      <p>These are the best free Resources available, which best suits for you to study this program.</p>
                            <Link to="https://www.javatpoint.com/cpp-tutorial" className="btn btn-link">Resource01</Link>
                            <Link to="https://www.geeksforgeeks.org/c-plus-plus/" className="btn btn-link">Resource02</Link>
                            <Link to="https://www.w3schools.com/cpp/" className="btn btn-link">Resource03</Link></center>
                    </div>
                    </div>
                    </div>


                    <div className="col-md-4"> 
                    <div className="card shadow event-card event-card-hover"> 
                    <img src={Services4} className="w-100 border-bottom event-image" alt="Services" style={{height:'10rem'}}/> 
                    <div className="card-body event-info"> 
                    <center> <h3>Sql</h3>
                      <div className="underline"></div><br/>
                      <p>These are the best free Resources available, which best suits for you to study this program.</p>
                            <Link to="https://www.geeksforgeeks.org/sql-tutorial/" className="btn btn-link">Resource01</Link>
                            <Link to="https://www.javatpoint.com/sql-tutorial" className="btn btn-link">Resource02</Link>
                            <Link to="https://www.w3schools.com/sql/default.asp" className="btn btn-link">Resource03</Link></center>
                    </div>
                    </div>
                    </div>


                  <div className="col-md-4"> 
                    <div className="card shadow event-card event-card-hover"> 
                    <img src={Services1} className="w-100 border-bottom event-image" alt="Services" style={{height:'10rem'}}/> 
                    <div className="card-body event-info"> 
                    <center> <h3>Core Java</h3>
                      <div className="underline"></div><br/>
                            <p>These are the best free Resources available, which best suits for you to study this program.</p>
                            <Link to="https://www.javatpoint.com/java-tutorial" className="btn btn-link">Resource01</Link>
                            <Link to="https://www.geeksforgeeks.org/java/" className="btn btn-link">Resource02</Link>
                            <Link to="https://www.w3schools.com/java/" className="btn btn-link">Resource03</Link></center>
                    </div>
                    </div>
                    </div>


        </div>
        </div>
            </section>




    );

}

export default Free;