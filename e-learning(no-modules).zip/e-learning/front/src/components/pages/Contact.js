import React from 'react';
import Linkdin from '../images/media/linkedin.jpeg';
import Twitter from '../images/media/twitter.jpeg';
import Fb from '../images/media/fb.jpeg';
import Insta from '../images/media/insta.jpeg';
import Navbar from '../inc/Navbar';
import Footer from '../inc/Footer';

function Contact(){
    return (

        <div>

            {/* this is navbar section */}
            <Navbar/>

            <section className="py-4 bg-gray" style={{ backgroundColor:'gray' }}>
                <div className="container">
                    <div className="row">
                            <div className="col-md-4 my-auto" >
                                <h4 style={{color:'red' }}>Contact Us</h4>
                            </div>
                            <div className="col-md-8 my-auto">
                                 <h6 className="float-end" style={{ color:'red' }}>
                                    Home / Contact Us
                                 </h6>
                            </div>
                    </div>
                </div>
            </section>

            <section className="section">
                <div className="container">
                    <div className="card shadow">
                        <div className="card-body">
                            <div className="row">
                                <div className="col-md-6">
                                    <center><h5 className='main-heading'>Enter Details!</h5>
                                    <div className="underline"></div>
                                    <hr/>
                                    <div className="form-group">
                                        <label className="mb-1">Enter your Name:</label>
                                        <input type="text" className="form-control" placeholder="sxxxxxx" />
                                    </div><br/>
                                    <div className="form-group">
                                        <label className="mb-1">Enter Phone Number:</label>
                                        <input type="text" className="form-control" placeholder="88XXXXXXX" />
                                    </div><br/>
                                    <div className="form-group">
                                        <label className="mb-1">Enter Email Address:</label>
                                        <input type="email" className="form-control" placeholder="abcxyz@gmail.com" />
                                    </div><br/>
                                    <div className="form-group">
                                        <label className="mb-1">Your Feedback:</label>
                                        <textarea rows="3" className="form-control" placeholder="xyz message..."></textarea>
                                    </div>

                                    <div className="form-group py-3">
                                        <button type="button" className="btn btn-primary shadow w-100">Send Message</button>
                                    </div></center>

                                    

                                </div>
                                <div className="col-md-6 border-start">
                                    <center><h5 className="main-heading">Address-Information</h5>
                                        <div className="underline"></div><br/><br/>
                                        <p>
                                            Jalandhar , Punjab , India
                                        </p>

                                        <p>
                                            Phone: +91 8810862625
                                        </p>

                                        <p>
                                            Email: bm.bijaymishra@gmail.com
                                        </p></center>



                                        <br/><br/><center><h5 className="main-heading">Social Media Handles</h5>
                                        <div className="underline"></div><br/><br/>
                                        <a href="https://www.linkedin.com/login" target="_blank" rel="noopener noreferrer">
                                            <img src={Linkdin} style={{height:'15px',width:'20px'}} alt="LinkedIn" />
                                        </a>
                                        &nbsp; &nbsp; &nbsp; 
                                        <a href="https://twitter.com/?lang=en" target="_blank" rel="noopener noreferrer">
                                            <img src={Twitter} style={{height:'20px',width:'25px'}} alt="Twitter" />
                                        </a>
                                        &nbsp; &nbsp; &nbsp; 
                                        <a href="https://www.facebook.com/" target="_blank" rel="noopener noreferrer">
                                            <img src={Fb} style={{height:'15px',width:'20px'}} alt="Facebook" />
                                        </a>
                                        &nbsp; &nbsp; &nbsp;  
                                        <a href="https://www.instagram.com/" target="_blank" rel="noopener noreferrer">
                                            <img src={Insta} style={{height:'15px',width:'20px'}} alt="Instagram" />
                                        </a></center>
                    






                                </div>

                                
                            </div>
                        </div>

                    </div>
                </div>

            </section>


            {/* this is footer section */}
            <Footer/>

        </div>




    );
}

export default Contact;