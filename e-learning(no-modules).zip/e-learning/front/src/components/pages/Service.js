import React from 'react';
import Free from './inc/Free';
import Premium from './inc/Premium';

function Service()
{
    return(

        <section className="section border-top">
        <div className="container">
            <div className="row">
                    <div className="col-md-12 mb-5 text-center">
                        <h3 className='main-heading'>CLR SERVICES</h3>
                        <div className="underline mx-auto"></div>
                    </div>

                        {/* get free resources */}

                        <Free/>

                        {/* preparation for gate exams */}

                        <Premium/>


        </div>
        </div>
            </section>



    );
}

export default Service;