import React from 'react';
import Slider from '../inc/Slider';
import { Link } from 'react-router-dom';
import Premium from './inc/Premium';
import Footer from '../inc/Footer';
import Navbar from '../inc/Navbar';

function Home(){
    return (
        <div>

        {/* this is navbar section */}
            <Navbar/>
           
           {/* slider is here  */}
            <Slider/>

           {/* our services */}
            <Premium/>
        
          {/* our company description */}
          <br/><br/><section className="section">
                <div className="container">
                    <div className="row">
                        <div className="col-md-12 text-center">
                            <h3 className='main-heading'>Our Company</h3>
                            <div className="underline mx-auto"></div><br/>
                            <h6><strong>Founded by Mr. Bijay Kumar Mishra in 2024 , Comprehensive Learning Repository (CLR) is a comprehensive online learning platform designed to empower individuals to achieve their goals by providing a wide range of educational resources. CLR recognizes the importance of accessibility and offers a unique combination.</strong></h6>
                            <br/><Link to="/about" className="btn btn-warning shadow">Read More</Link>
                        </div>
                    </div>
                </div>
            </section><br/><br/>


{/* this is footer section */}
            <Footer/>

        </div>
    );
}

export default Home;