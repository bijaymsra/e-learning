import React from 'react';
import Vmc from './inc/Vmc';
import Navbar from '../inc/Navbar';
import Footer from '../inc/Footer';
function About(){
    return (
        <div>
             {/* this is navbar section */}
             <Navbar/>
       
            <section className="py-4 bg-bg-info" style={{ backgroundColor:'gray' }}>
                <div className="container">
                    <div className="row">
                            <div className="col-md-4 my-auto">
                                <h4 style={{ color:'red'}}>About Us</h4>
                            </div>
                            <div className="col-md-8 my-auto">
                                 <h6 className="float-end" style={{ color:'red'}}>
                                    Home / About Us
                                 </h6>
                            </div>
                    </div>
                </div>
            </section>

            <section className="section border-bottom">
                <div className="container">
                    <center><h5 className="main-heading">Our Company</h5>
                    <div className="underline"></div></center>
                                        
                  <br/> <h6><strong>Founded in 2024 by Mr. Bijay Kumar Mishra, Comprehensive Learning Repository (CLR)</strong> is a comprehensive online learning platform designed to empower individuals to achieve their goals by providing a wide range of educational resources. CLR recognizes the importance of accessibility and offers a unique combination of:</h6>

                    <br/>
                    <ul>
                    <li>
                        <strong>Free Resources:</strong> Understanding that financial barriers can hinder learning, CLR offers a substantial free category with valuable resources for students who may not be able to afford premium options. This free section includes a variety of learning materials, such as:
                        <ul>
                        <li>Textbooks and ebooks</li>
                        <li>Lecture notes and presentations</li>
                        <li>Practice quizzes and tests</li>
                        <li>Tutorials and guides</li>
                        </ul>
                    </li><br/>
                    <li>
                        <strong>Premium Paid Categories:</strong> For those seeking deeper learning experiences, CLR provides premium paid categories across diverse topics. These categories offer:
                        <ul>
                        <li>In-depth courses from accredited institutions and experienced instructors</li>
                        <li>Interactive exercises and practice problems</li>
                        <li>Personalized learning plans and progress tracking</li>
                        <li>Downloadable resources and certificates</li>
                        </ul>
                    </li><br/>
                    <li>
                        <strong>Curated Recommendations:</strong> CLR goes beyond its own library and provides curated recommendations for external websites and videos that can supplement your learning journey. This ensures you have access to the most relevant and helpful resources available online.
                    </li>
                    </ul>


                </div>

            </section>

          {/* our vision , mission and values */}

            <Vmc/>


            {/* this is footer section */}
            <Footer/>

        </div>
    );
}

export default About;