import React, { useEffect } from 'react';

function Note(){
    useEffect(() => {
        // Redirect to http://localhost:3001/
        window.location.href = 'http://localhost:3001/';
    }, []);

    // This component doesn't render anything as it immediately redirects
    return null;
}

export default Note;
