import React from 'react';
import {Link} from 'react-router-dom';
import  Search from './Search';


function Navbar(){
    return (


<div className="navbar-dark bg-dark shadow">


  <nav class="navbar navbar-expand-lg">
  <div class="container-fluid">


  <Link to="/" class="navbar-brand text-white" style={{fontWeight:'bold', fontSize: '35px' }}>CLR</Link>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
        <Link to="/" class="nav-link active text-white" ><button type="button" class="btn btn-outline-secondary text-white">Home</button></Link>
        </li>


      {/* this is our services */}
        <li class="nav-item dropdown">
           <a class="nav-link text-white" href="/" role="button" data-bs-toggle="dropdown" aria-expanded="false">
           <button type="button" class="btn btn-outline-secondary text-white">Our Services</button>
           </a>

          <ul class="dropdown-menu bg-info">
          <center><li><Link to="/free" className="dropdown-item">Get Free Resources</Link></li>
            <li><Link to="/premium" className="dropdown-item">Premium Resources</Link></li>
            <li><hr class="dropdown-divider"/></li>
            <li><Link to="/service" className="dropdown-item">Get All</Link></li></center>
          </ul>
        </li>


         {/* this is about section */}
        <li class="nav-item">
        <Link to="/about" class="nav-link active text-white" ><button type="button" class="btn btn-outline-secondary text-white">About Us</button></Link>
        </li>

          {/* this is for contact us section */}
        <li class="nav-item">
        <Link to="/contact" class="nav-link active text-white" ><button type="button" class="btn btn-outline-secondary text-white">Contact Us</button></Link>
        </li>

         {/* this is  note section */}
        <li class="nav-item">
        <Link to="/note" class="nav-link active text-white" ><button type="button" class="btn btn-outline-secondary text-white">Make Notes</button></Link>
        </li>



        </ul>

      {/* this is search section */}
      <Search/>

    </div>
  </div>
</nav>
  
    
</div>

    );
}

export default Navbar;