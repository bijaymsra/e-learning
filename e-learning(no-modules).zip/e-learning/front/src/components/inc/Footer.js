import React from "react";
import { Link } from 'react-router-dom';

function Footer()
{
    return(

        <section className="section footer bg-dark text-white">
            <div className="container">
                <div className="row">
                    <div className="col-md-4">
                        <h6>Company Information</h6>
                        <hr/>
                        <p className="text-white">
                        Founded by Mr. Bijay Kumar Mishra in 2024, Comprehensive Learning Repository (CLR) is a comprehensive online learning platform designed to empower individuals to achieve their goals by providing a wide range of educational resources. CLR recognizes the importance of accessibility and offers a unique combination.
                        </p>
                        

                    </div>
                <div className="col-md-4">
                    <h6>Quick Links</h6>
                    <hr/>
                    <div><Link to="/">Home</Link></div><br/>
                    <div><Link to="/service">Services</Link></div><br/>
                    <div><Link to="/about">Blogs</Link></div>
                </div>
                <div className="col-md-4">
                <h6>Contact Information</h6>
                <hr/>
                <div><p className="text-white mb-1">Jalandhar , Punjab , India</p></div>
                <div><p className="text-white mb-1">+91 8810862625</p></div>
                <div><p className="text-white mb-1">+91 8810862625</p></div>
                <div><p className="text-white mb-1">bm.bijaymishra@gmail.com</p></div> <br/>

                </div>

                </div>

            </div>


        </section>

    );
}

export default Footer;