import React from 'react';
import Slider1 from '../images/slider/s1.avif';
import Slider2 from '../images/slider/s2.avif';
import Slider3 from '../images/slider/s3.avif';

function Slider()
{
    return (

  <div id="carouselExampleCaptions" class="carousel slide">

  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src={Slider1} className="d-block w-100" alt="Responsive img" style={{height:'45rem'}}/>

      {/* first page */}
      <div class="carousel-caption d-none d-md-block">
        <h3 style={{color:'white'}}><strong>Welcome to Comprehensive Learning Repository</strong></h3>
        <h5 style={{color:'wheat'}}><strong>"Your GateWay to Mastery"</strong></h5>
      </div>
    </div>

      {/* second page */}
    <div class="carousel-item">
    <img src={Slider2} className="d-block w-100" alt="Responsive img" style={{height:'45rem'}}/>
      <div class="carousel-caption d-none d-md-block">
        <h3 style={{color:'white'}}><strong>A warm welcome from "Comprehensive Learning Repository"</strong></h3>
        <h5 style={{color:'wheat'}}><strong>"Simply reading isn't enough.To truly learn, actively participate, practice, and seek opportunities to apply what you've learned."</strong></h5>
      </div>
    </div>

      {/* third page */}
    <div class="carousel-item">
    <img src={Slider3} className="d-block w-100" alt="Responsive img" style={{height:'45rem'}}/>
      <div class="carousel-caption d-none d-md-block">
        <h3 style={{color:'white'}}><strong>Comprehensive Learning Repository Welcomes</strong></h3>
        <h5 style={{color:'wheat'}}><strong>"Don't wait for the "perfect" moment. Begin your learning journey with the resources you have today."</strong></h5>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>

        </div>
    );
}

export default Slider;